To run MarbleMadness:

1. Locate the folder MarbleMadness, which should have in it files named
MarbleMadness and Assets.  It's likely that the path to the folder will be
/Users/yourname/MarbleMadness or /Users/yourname/Downloads/MarbleMadness.

2. Open a Terminal window and type
        cd whateverThePathIs
where you should replace whateverThePathIs with the path to the
MarbleMadness folder.

3. Confirm you're in the right folder by typing
        ls
which should show you the Assets folder and the MarbleMadness executable.

4. Type
        ./MarbleMadness
to play the game.

Alternatively, in the folder MarbleMadness, you can move the Assets folder
to your home directory, then double-click on the MarbleMadness executable
file.
